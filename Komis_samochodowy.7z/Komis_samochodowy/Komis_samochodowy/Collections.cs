﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Komis_samochodowy
{
    class Collections
    {
        public void samochody ()
        {
            List<string> lst = new List<string>();
            lst.Add("Audi");
            lst.Add("BMW");
            lst.Add("Citroen");
            lst.Add("Skoda");
        }
    }
}

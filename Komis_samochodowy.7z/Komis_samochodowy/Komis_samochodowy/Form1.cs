﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Komis_samochodowy
{
    public partial class Form1 : Form
    {
        public void Kolekcje ()
        {
             comboBox1.Items.AddRange
                (
                    new object[]
                    {
                        "Audi",
                        "BMW",
                        "Citroen",
                        "Skoda"
                    }
                );
        }

        public Form1()
        {
           InitializeComponent();
           Kolekcje();
        }
       

        public void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {


            List<string> audi = new List<string>();
            audi.Add("a2");
            audi.Add("a3");
            audi.Add("a4");
            audi.Add("a7");

            List<string> bmw = new List<string>();
            bmw.Add("e46");
            bmw.Add("e90");
            bmw.Add("e60");
            bmw.Add("e34");

            List<string> citroen = new List<string>();
            citroen.Add("c2");
            citroen.Add("c3");
            citroen.Add("c4");
            citroen.Add("c5");

            List<string> skoda = new List<string>();
            skoda.Add("fabia");
            skoda.Add("oktavia");
            skoda.Add("favorit");
            skoda.Add("superb");

            List<string> silnikaudi = new List<string>();
            silnikaudi.Add("1.4 TFSI 150KM");
            silnikaudi.Add("2.0 TFSI 190KM");
            silnikaudi.Add("2.0 TDI  150KM");
            silnikaudi.Add("2.0 TDI  190KM");

            List<string> silnikcitroen = new List<string>();
            silnikcitroen.Add("1.4 THP 165KM");
            silnikcitroen.Add("2.0 THP 210KM");
            silnikcitroen.Add("2.0 HDI 120KM");
            silnikcitroen.Add("2.2 HDI 170KM");

            List<string> silnikbmw = new List<string>();
            silnikbmw.Add("316i 122KM");
            silnikbmw.Add("318i 143KM");
            silnikbmw.Add("316d 115KM");
            silnikbmw.Add("320d 163KM");

            List<string> silnikskoda = new List<string>();
            silnikskoda.Add("1.4 TFSI 120KM");
            silnikskoda.Add("1.8 TFSI 140KM");
            silnikskoda.Add("1.4 TDI  110KM");
            silnikskoda.Add("2.0 TDI  190KM");

            comboBox2.Items.Clear();
            switch (comboBox1.SelectedItem)
            {
               case "Audi":
                    foreach (string s in audi)
                    {
                        comboBox2.Items.Add(s);
                    }
                    listView2.Items.Clear();
                    foreach (string s in silnikaudi)
                    {
                        listView2.Items.Add(s);
                    }
                    break;
                case "BMW":
                    foreach (string s in bmw)
                    {
                        comboBox2.Items.Add(s);
                    }
                    listView2.Items.Clear();
                    foreach (string s in silnikbmw)
                    {
                        listView2.Items.Add(s);
                    }
                    break;
                case "Citroen":
                    foreach (string s in citroen)
                    {
                        comboBox2.Items.Add(s);
                    }
                    listView2.Items.Clear();
                    foreach (string s in silnikcitroen)
                    {
                        listView2.Items.Add(s);
                    }
                    break;
                case "Skoda":
                    foreach (string s in skoda)
                    {
                        comboBox2.Items.Add(s);
                    }
                    listView2.Items.Clear();
                    foreach (string s in silnikskoda)
                    {
                        listView2.Items.Add(s);
                    }
                    break;
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string dir = @"C:\Users\dariu\source\repos\Komis_samochodowy\img\";
            string rest="";
            switch (comboBox2.SelectedItem)
            {
                case "a2":
                    rest = @"a2.jpg";
                    break;
                case "a3":
                    rest = @"a3.jpg";
                    break;
                case "a4":
                    rest = @"a4.jpg";
                    break;
                case "a7":
                    rest = @"a7.jpg";
                    break;
                case "e46":
                    rest = @"e46.jpg";
                    break;
                case "e90":
                    rest = @"e90.jpg";
                    break;
                case "e60":
                    rest = @"e60.jpg";
                    break;
                case "e34":
                    rest = @"e34.jpg";
                    break;
                case "c2":
                    rest = @"c2.jpg";
                    break;
                case "c3":
                    rest = @"c3.jpg";
                    break;
                case "c4":
                    rest = @"c4.jpg";
                    break;
                case "c5":
                    rest = @"c5.jpg";
                    break;
                case "fabia":
                    rest = @"fabia.jpg";
                    break;
                case "oktavia":
                    rest = @"octavia.jpg";
                    break;
                case "favorit":
                    rest = @"favorit.jpg";
                    break;
                case "superb":
                    rest = @"superb.jpg";
                    break;
            }
            Bitmap bit;
            bit = new Bitmap(dir + rest, true);
            pictureBox1.Image = bit;
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;


            radioButton1.Enabled = true;
            radioButton2.Enabled = true;
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            List<string> kolornormalny = new List<string>();
            kolornormalny.Add("czerwony");
            kolornormalny.Add("zielony");
            kolornormalny.Add("czarny");
            kolornormalny.Add("żółty");
            kolornormalny.Add("niebieski");
            kolornormalny.Add("złoty");
            kolornormalny.Add("biały");
            kolornormalny.Add("granatowy");
            listView1.Items.Clear();

            if (radioButton1.Checked == true)
            {
                radioButton1.Checked = true;
                radioButton2.Checked = false;
            }

                    foreach (string s in kolornormalny)
                    {
                        listView1.Items.Add(s);
                    }
           
        }
        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            List<string> kolormetaliczny = new List<string>();
            kolormetaliczny.Add("perłowy");
            kolormetaliczny.Add("habrowy");
            kolormetaliczny.Add("butelkowy");
            kolormetaliczny.Add("łososiowy");
            listView1.Items.Clear();
            if (radioButton2.Checked == true)
            {
                radioButton1.Checked = false;
                radioButton2.Checked = true;
            }

            foreach (string s in kolormetaliczny)
            {
                listView1.Items.Add(s);
            }
        }
        
    }



}
